
abstract class Value extends Server {

    public static Value trueval = new VBool(true);
    public static Value falseval = new VBool(false);

    LinSession call(String _chi) throws Exception{
        LinSession session = LinSession.newLinearSessionId(_chi);
        Value linValue = this;
		CLLSj.threadPool.inc_active();
        CLLSj.threadPool.submit(
                new Runnable(){
                    public void run(){ try{
                        session.send(linValue);
			            CLLSj.threadPool.dec_active();
                    }catch (Exception e) { e.printStackTrace(System.out);} }
                });
        return session;
    }

    
    abstract String toStr();
    abstract boolean equal(Value v);
}
