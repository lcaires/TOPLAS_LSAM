public class IndexedSessionRef extends SessionField {

    int offset;
    SessionRecord srec;

    IndexedSessionRef (int _ofs, SessionRecord _srec)
    {
	//	System.out.println("IndexedSessionRef("+_ofs+")");
	offset = _ofs;
	srec = _srec;
    }

    public int getOffset()
    {
	return offset;
    }
    
    public void resetOffset()
    {
	 offset = 0;
    }

    public void setOffset(int off)
    {
	offset = off;
    }
   
    public void incOffset()
    {
	//	System.out.println("incOffset "+this);
	offset++;
    }

    public SessionRecord getSessionRec()
    {
	    return srec;
    }

    public void setSessionRec(SessionRecord s)
    {
	    srec = s;
    }

    void UpdSessionRefInplace(SessionRecord srec, int offs) {
        this.setOffset(offs);
        this.setSessionRec(srec);
    }
    
    void dump() {
        System.out.println("offset ="+offset);
        System.out.println("s[0] ="+srec.slots[0]);
        System.out.println("s[1] ="+srec.slots[1]);
    }
}
