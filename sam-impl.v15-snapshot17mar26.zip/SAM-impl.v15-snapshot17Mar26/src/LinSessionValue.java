public class LinSessionValue extends SessionField {
    LinSession lin;

    public LinSessionValue(String id)
    {
	lin = LinSession.newLinearSessionId(id);
    }

    LinSession getLin() {
	return lin;
    }
}
