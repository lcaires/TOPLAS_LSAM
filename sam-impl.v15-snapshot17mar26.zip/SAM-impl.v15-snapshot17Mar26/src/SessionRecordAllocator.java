public class SessionRecordAllocator {
    
    static final int MAXS = 17;
    SessionRecord cache[];
    int statsalloc[];
    int statsnew[];
    volatile int maxalloc = 0;
    volatile int totalloc = 0;

    public SessionRecordAllocator()
    {
        cache = new SessionRecord[MAXS];
        statsalloc = new int[MAXS];
        statsnew = new int[MAXS];
        maxalloc = 0;
    }

	//synchronized 
    SessionRecord newSessionRecord(int _size)
    {    
        totalloc++;
        if (cache[_size]==null)  {
            statsalloc[_size]++;
            maxalloc++;
            return new SessionRecord(_size);
         } else  {
            SessionRecord sr = cache[_size];
            cache[_size] = sr.next_free;
            sr.cont = new SessionClosure();
            sr.next_free = null;
            sr.polarity = true;
            sr.polarity_dual = false;
            return sr;
        } 
    }

	//synchronized 
    void freeSessionRecord(SessionRecord sr)
    {
        int sz = sr.getSize();	
        sr.next_free = cache[sz];
        cache[sz]=sr;  
    }

    void reset_alloc() {
        maxalloc = 0;
        totalloc = 0;
    }

    int max_alloc() {
        return maxalloc;
    }

    int tot_alloc() {
        return totalloc;
    }

    synchronized void merge(SessionRecordAllocator mem)
    {
        int im = mem.max_alloc();
        maxalloc += im; 
        totalloc += mem.totalloc;
    }

}
