import java.io.*;

class VFileHandle extends  Value {

    InputStream fi;

    VFileHandle(InputStream _fi){
        this.fi = _fi;
    }

    int read() throws Exception {
        return fi.read();
    }

    void close() throws Exception {
        fi.close();
    }

    String toStr(){
        return " "+fi;
    }

    boolean equal(Value v) {
	return false;
    }

}
