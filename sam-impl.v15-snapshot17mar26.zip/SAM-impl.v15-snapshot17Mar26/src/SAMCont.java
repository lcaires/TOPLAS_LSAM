    public class SAMCont  {

    public ASTNode code;
    public Env<SessionField> frame;
    public Env<EnvEntry> epnm;
    public SessionRecordAllocator malloc;

    static SAMCont Null = new SAMCont(null, null, null,null);
    
    public SAMCont(ASTNode _code,  Env<SessionField> _frame,
            Env<EnvEntry> _epnm, SessionRecordAllocator _malloc)
    {
        code = _code;
        frame = _frame;
        epnm = _epnm;
        malloc = _malloc;
    }	
};;

	
