import java.util.concurrent.*;

public class ExecutorWrapper {

private volatile int num_submits = 0;
private volatile int max_active = 0;
private volatile int current_active = 0;
private boolean vt;

private ExecutorService threadPool_core;

public ExecutorWrapper(ExecutorService core, boolean virt)
{
    threadPool_core = core;
    vt = virt;
}

static void install_threads(ExecutorService threadPool,int nt)
{
     /* 
    for(int i=0;i<nt;i++)
    {
        threadPool.execute(
				new Runnable(){public void run(){
				    try {
	    				Thread.sleep(10);
				    }catch (Exception e){ e.printStackTrace(System.out); }
				}});
    }
    */
}

public synchronized void reset_count()
{
    num_submits = 1;
    max_active = 1;
    current_active = 0;
}

public synchronized int get_count()
{
    return num_submits;
}

public synchronized int max_active()
{
    return max_active;
}

public synchronized void inc_active()
{
    current_active++;
}

public synchronized void dec_active()
{
    current_active--;
}


public Future<?> submit(Runnable task){
    Future <?> f=null;
    int m;
    f = threadPool_core.submit(task);
    if (vt) 
        m = current_active;
    else m = this.getActiveCount();
    if (m>max_active)
        max_active = m;
    // num_submits += 1;
    return f;
}

public synchronized int getActiveCount() {
    if (vt) return current_active;
return ((ThreadPoolExecutor)(threadPool_core)).getActiveCount();

}

}
