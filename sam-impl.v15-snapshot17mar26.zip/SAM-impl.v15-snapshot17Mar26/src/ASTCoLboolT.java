public class ASTCoLboolT extends ASTCoLBasicType {

    public boolean equalst(ASTType t, Env<EnvEntry> e, boolean lit, Trail trail) throws Exception {
	t = t.unfoldType(e);
	return (t instanceof ASTCoLboolT);
    }


    public void kindcheck(Env<EnvEntry> e) throws Exception
    {
    }

    public ASTType dual(Env<EnvEntry> e) {
	return new ASTLboolT();
    }

    public String toStr(Env<EnvEntry> e) {
	return "COLBOOL";
    }

    public ASTType unfoldType(Env<EnvEntry> e) throws Exception
    {
	return this;
    }

    public  ASTType subst(Env<ASTType> e) {
	    return this;
    }
    
    public int SetOffsets(int base, Env<EnvEntry> e) throws Exception
    {
	// offset = base;
	return base;
    }

}
