
public class ASTCoFileT extends ASTBasicType {

    public boolean equalst(ASTType t, Env<EnvEntry> e, boolean lit, Trail trail) throws Exception {
	t = t.unfoldType(e);
	return (t instanceof ASTCoFileT);
    }


    public void kindcheck(Env<EnvEntry> e) throws Exception
    {
    }

    public ASTType dual(Env<EnvEntry> e) {
	return new ASTFileT();
    }

    public String toStr(Env<EnvEntry> e) {
	return "COFILE";
    }

    public ASTType unfoldType(Env<EnvEntry> e) throws Exception
    {
	return this;
    }

    public  ASTType subst(Env<ASTType> e) {
	    return this;
    }
    
    public int SetOffsets(int base, Env<EnvEntry> e) throws Exception
    {
	return base;
    }

}
