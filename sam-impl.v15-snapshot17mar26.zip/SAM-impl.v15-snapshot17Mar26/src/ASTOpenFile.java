import java.util.*;
import java.util.function.*;
import java.util.logging.*;
import java.io.*;  

public class ASTOpenFile extends ASTNode {

  String ch;
  ASTExpr fn;  
  ASTNode rhs;

  public ASTOpenFile(String _ch, ASTExpr _fn, ASTNode _rhs) {
    ch = _ch;
    fn = _fn;
    rhs = _rhs;
  }

    public String getCh() {
    return ch;
  }

  public void setCh(String ch) {
    this.ch = ch;
  }

  public void ASTupdCont(ASTNode newCont, ASTNode caller) throws Exception {
    throw new Exception("ASTupdCont: call not expected");
  }

  public void ASTInsertPipe(Function<ASTNode, ASTNode> f, ASTNode from) throws Exception {
    throw new Exception("ASTInsertPipe: call not expected");
  }

  public void ASTInsertUse(String ch, ASTType t, ASTNode here, Boolean disCont) throws Exception {
    anc.ASTInsertUse(ch, t, this, disCont); // insert above up
  }

  public void ASTInsertCall(String ch, String cho, ASTType t, ASTNode here) throws Exception {
    anc.ASTInsertCall(ch, cho, t, this); // insert above up
  }

  public void ASTInsertWhyNot(String ch, ASTType _t, ASTNode here) throws Exception {
    anc.ASTInsertWhyNot(ch, _t, this);
  }

  public ASTNode ASTweakeningOnLeaf(String _ch, ASTType t, boolean exp) throws Exception {
    return this;
  }

  public void typecheck(Env<ASTType> ed, Env<ASTType> eg, Env<EnvEntry> ep) throws Exception {
  ASTType et;
	try {
	    et =fn.etypecheck(ed,eg,ep,false);
	} catch (Exception ee) {
	    et = fn.etypecheck(ed,eg,ep,true);
	};
	if (!(et instanceof ASTCoLstringT))
	    throw new TypeError("Line " + lineno + " :" +"OPENFILE : string expected");
    eg = eg.assoc(ch, new ASTCoFileT());
    rhs.typecheck(ed,eg,ep);
  }

  public Set<String> fn(Set<String> s) {
    return s;
  }

  public Set<String> fnLinear(Set<String> s) {
    return s;
  }

  public ASTNode subst(Env<ASTType> e) {
    return this;
  }

  public void subs(String x, String y) { // implements x/y (substitutes y by x)
    if (ch.equals(y)) {
      ch = x; // Substitute ch by x
    }
  }

  public void runproc(Env<EnvEntry> ep, Env<Session> ed, Env<Server> eg, Logger logger)
      throws Exception {
     	VString v = (VString)fn.eval(ed,eg);
      InputStream fi = new FileInputStream(v.get());
      eg = eg.assoc(ch,new VFileHandle(fi));
      rhs.runproc(ep,ed,eg,logger);
  }

  public void samL(Env<SessionField> frame, Env<EnvEntry> ep, SAMCont p_cont) throws Exception {
    VString fns = (VString)fn.sameval(frame,p_cont.malloc);
    FileInputStream fi = new FileInputStream(fns.get());
    Value v = new VFileHandle(fi); 
	  if (CLLSj.trace) {
	    System.out.println("openfile-lib "+fi);
	  }
	  p_cont.code = rhs;
    p_cont.frame = frame.assoc(ch, v);
	  p_cont.epnm = ep;
  }

  public String toStr(Env<EnvEntry> ep) throws Exception {
    return "openfile (" + ch + ")";
  }

  public void show() {
    System.out.println(this);
  }
}
