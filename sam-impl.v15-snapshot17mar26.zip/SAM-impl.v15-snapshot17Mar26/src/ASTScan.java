import java.util.*;
import java.util.function.*;
import java.util.logging.*;

public class ASTScan extends ASTNode {

  String fh;
  String ch;
  ASTType type;
  boolean isScanc = false;

  public ASTScan(String _fh, String _ch, ASTType _type, boolean scanc) {
    fh = _fh;
    ch = _ch;
    type = _type;
    isScanc = scanc;
  }

  public String getCh() {
    return ch;
  }

  public void setCh(String ch) {
    this.ch = ch;
  }

  public ASTType getType() {
    return type;
  }

  public boolean isScanc() {
    return isScanc;
  }

  public void ASTupdCont(ASTNode newCont, ASTNode caller) throws Exception {
    throw new Exception("ASTupdCont: call not expected");
  }

  public void ASTInsertPipe(Function<ASTNode, ASTNode> f, ASTNode from) throws Exception {
    throw new Exception("ASTInsertPipe: call not expected");
  }

  public void ASTInsertUse(String ch, ASTType t, ASTNode here, Boolean disCont) throws Exception {
    anc.ASTInsertUse(ch, t, this, disCont); // insert above up
  }

  public void ASTInsertCall(String ch, String cho, ASTType t, ASTNode here) throws Exception {
    anc.ASTInsertCall(ch, cho, t, this); // insert above up
  }

  public void ASTInsertWhyNot(String ch, ASTType _t, ASTNode here) throws Exception {
    anc.ASTInsertWhyNot(ch, _t, this);
  }

  public ASTNode ASTweakeningOnLeaf(String _ch, ASTType t, boolean exp) throws Exception {
    return this;
  }

  public void typecheck(Env<ASTType> ed, Env<ASTType> eg, Env<EnvEntry> ep) throws Exception {

	  ASTType tyf = eg.find(fh);
  
    if (!(tyf instanceof ASTCoFileT)) {
      throw new TypeError(
          "Line "
              + lineno
              + " :"
              + "SCAN "
              + ch
              + " not cofile type (found "
              + tyf.toStr(ep)
              + ")");
    }

    ASTType t = type;

    if (t instanceof ASTBangT) {
      t = ((ASTBangT) t).getin();
    }

    if (!(t instanceof ASTBasicType)) {
      throw new TypeError(
          "Line "
              + lineno
              + " :"
              + "SCAN "
              + ch
              + " not of (optionally exponential) basic type (found "
              + type.toStr(ep)
              + ")");
    }

    if (isScanc && !(t instanceof ASTLstringT)) {
      throw new TypeError(
          "Line "
              + lineno
              + " :"
              + "SCANCHAR "
              + ch
              + " not of (optionally exponential) string type (found "
              + type.toStr(ep)
              + ")");
    }
    ed.upd(ch,null);
  }

  public Set<String> fn(Set<String> s) {
    s.add(ch);
    return s;
  }

  public Set<String> fnLinear(Set<String> s) {
    return s;
  }

  public ASTNode subst(Env<ASTType> e) {
    return new ASTScan(fh, ch, type == null ? null : type.subst(e), isScanc);
  }

  public void subs(String x, String y) { // implements x/y (substitutes y by x)
    if (ch.equals(y)) {
      ch = x; // Substitute ch by x
    }
  }

  private Value charFromStdin() throws Exception {
    int c = System.in.read();
    if (c == -1) {
      return new VString("");
    }
    return new VString("" + (char) c);
  }

  private Value tokenFromStdin(ASTType typ, VFileHandle vf) throws Exception {
    String s="";
    int nchar = vf.read();
    while (nchar <= ' ') {
      nchar = vf.read();
    };
    while (nchar > ' ') {
      s = s+Character.toString((char)nchar);;
      nchar = vf.read();
    }
    if (typ instanceof ASTLboolT) {
      if (s.equals("true")) {
        return Value.trueval;
      } else
      if (s.equals("false")) {
        return Value.falseval;
      }
  } else if (typ instanceof ASTLintT) {
        try {
          int val = Integer.parseInt(s);
          return new VInt(val);
      } catch (Exception e) {
      }
    } else  if (typ instanceof ASTLstringT) { 
      return new VString(s);
    }
    throw new Exception("SCAN: I/O error");
  }

  private Value valueFromStdin(VFileHandle vf, Env<EnvEntry> ep) throws Exception {
    if (type instanceof ASTBangT) {
      type = ((ASTBangT) type).getin();
    }
   return tokenFromStdin(type,vf);   
  }

    public void runproc(Env<EnvEntry> ep, Env<Session> ed, Env<Server> eg, Logger logger)
      throws Exception {
    
    VFileHandle vf = (VFileHandle) eg.find(fh);
    Channel channel = (Channel) ed.find(ch);
    if (isScanc) {
      channel.send(charFromStdin());
    } else {
      channel.send(valueFromStdin(vf,ep));
    }
  }

  public void samL(Env<SessionField> frame, Env<EnvEntry> ep, SAMCont p_cont) throws Exception {

    VFileHandle vf = (VFileHandle) frame.find(fh);
    Value v = isScanc ? charFromStdin() : valueFromStdin(vf,ep);

    SessionField sf = frame.find(ch);

    if (sf instanceof IndexedSessionRef) {

      IndexedSessionRef sref = (IndexedSessionRef) frame.find(ch);
      int doffset = sref.getOffset();
      SessionRecord srec = sref.getSessionRec();

      if (CLLSj.trace) {
        System.out.println("scan-op " + ch + " " + srec + " @ " + doffset);
      }

      srec.writeSlot(v, doffset);
      sref.incOffset();

      ASTNode cont = srec.getCont();
      Env<SessionField> frm = srec.getFrame();
      Env<EnvEntry> epn = srec.getFrameP();

      srec.setPol(false);
      srec.setPolDual(true); // ended (don't care)
      srec.setFrame(frame);
      srec.setFrameP(ep);

      p_cont.code = cont;
      p_cont.frame = frm;
      p_cont.epnm = epn;

    } else {
      int u = 0 / 0;
    }
  }


  public String toStr(Env<EnvEntry> ep) throws Exception {
    return "scan (" + ch + ")";
  }

  public void show() {
    System.out.println(this);
  }
}
