public interface EnvEntry {

}
